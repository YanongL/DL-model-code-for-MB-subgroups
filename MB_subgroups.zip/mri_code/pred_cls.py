import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import numpy as np 
import os
import pandas as pd 
import random
from data_process.process_data import MriDataset,get_transforms2d, get_transforms3d
from models.model import ResNext, SeResNext, EfficientNet, ResNet
from models.unet3d import UNet3d
from models.segresnet3d import SegResNet
from models.vnet3d import VNet
from models.unet3dpp import UNetPlusPlus
from utils.util import get_score, get_argparse
import nibabel as nib

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

# def load_state(model_path):
#     model = ResNext(, pretrained=False)
#     try:  # single GPU model_file
#         model.load_state_dict(torch.load(model_path)['model'], strict=True)
#         state_dict = torch.load(model_path)['model']
#     except:  # multi GPU model_file
#         state_dict = torch.load(model_path)['model']
#         state_dict = {k[7:] if k.startswith('module.') else k: state_dict[k] for k in state_dict.keys()}

#     return state_dict
def predict_cls(model, states, test_loader, device):
    model.to(device)
    tk0 = tqdm(enumerate(test_loader), total=len(test_loader))
    probs = []
    pred_labels = []
    max_probs = []
    for i, batch_data in tk0:
        # images = images.to(device)
        img = batch_data['cls_image'].to(device, non_blocking=True, dtype=torch.float)
        # print(img.size())
        avg_preds = []
        for state in states:
            model.load_state_dict(state['state_dict'])
            model.eval()
            with torch.no_grad():
                y_preds = model(img)
            avg_preds.append(y_preds.softmax(1).detach().cpu().numpy())
        avg_preds = np.mean(avg_preds, axis=0)[0]
        # print(np.argmax(avg_preds))
        pred_labels.append(np.argmax(avg_preds))
        # print(np.max(avg_preds))
        max_probs.append(np.max(avg_preds))

        probs.append(avg_preds)
        # print('result is {}'.format(probs))
    # probs = np.concatenate(probs)
    return probs, pred_labels, max_probs



if __name__ == '__main__':
    args = get_argparse()
    args.model_name = 'resnet50'
    output_dir = './saved/cls/'
    test_data_path = './data/'
    # test_df = pd.read_csv('./test_data.tsv', sep='\t')
    fold_0_df = pd.read_excel('new_all_data_infos_class_v3_5fold_final.xlsx', converters={"Id": str})
    fold_0_df = fold_0_df[fold_0_df['fold']==0]
    fold_0_df = fold_0_df.reset_index(drop=True)
    # 丢弃一些无用的column
    fold_0_df.drop(columns=['Classification', 'Classification_v2'], inplace=True)

    # test_df = pd.DataFrame(columns=['Id', 'sequence'])
    # test_df['Id'] = '20230213002651'
    # test_df['sequence'] = '801001_t1w_ir_c_fs.nii.gz'
    # print(test_df)
    # test_df.to_csv('./test_data.tsv', sep='\t', index=False, float_format='%.0f')
    test_transforms_3d = get_transforms3d(phase='test')
    test_transforms_2d = get_transforms2d(phase='test')
    # df_data = pd.read_excel('final_data_infos.xlsx', converters={"检查流水号": str})
    # test_df = df_data[df_data['is_train'] == 0].reset_index(drop=True)
    # model = UNet3d(spatial_dims=3, in_channels=3, out_channels=3, dropout=0.1)
    # model = UNetPlusPlus(in_channels=3, out_channels=3, features=(128, 128, 256, 512, 1024, 128), dropout=0.1)

    model = ResNet(model_name=args.model_name, pretrained=True, n_class=4, in_channels=24)
    states = [torch.load(os.path.join(output_dir, args.model_name+'-0.6632',f'fold-{fold}_best.bin')) for fold in range(1)]

    # model.load_state_dict(torch.load(os.path.join(output_dir, model_name, 'fold-0_best.bin'))['state_dict'])
    test_dataset = MriDataset(test_data_path, fold_0_df, test_transforms_2d, test_transforms_3d, phase='test', is_resize=True)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, 
                                num_workers=4, pin_memory=True)
    preds, pred_labels, max_probs = predict_cls(model, states, test_loader, device)
    # print(preds)
    # pred_label = np.argmax(preds)
    # print(pred_labels)
    pred_labels = [x+1 for x in pred_labels]
    fold_0_df['pred_res'] = pred_labels
    fold_0_df['pred_probs'] = max_probs
    fold_0_df.to_csv('./fold_0_pred_res.tsv', index=False, sep='\t')
    # print(preds)
    # 对preds进行阈值限定，大于0.5的为1
    # preds = (preds > 0.5)
    # nib.save(nib.Nifti1Image(preds.astype(np.float32), np.eye(4)), path)
    # print('Test data metric is {:.4f}'.format(get_score(test_df_data['label'].values, preds)))
    # submission
    # test_df_data['preds'] = preds
    # test_df_data['pred_logits'] = pred_logits
    # test_df_data[['image_name', 'label', 'preds', 'pred_logits']].to_csv('./test_data_pred.tsv', index=False, sep='\t')