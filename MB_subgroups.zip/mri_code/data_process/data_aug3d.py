import numpy as np 
import torch
import random

class RandomCrop3d(object):
    """
    Crop randomly the image in a sample
    Args:
    output_size (int): Desired output size
    """

    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image = sample['image']
        # if 'seg_label' in sample:
        # label = sample['seg_label']

        (c, h, w, d) = image.shape
        w1 = np.random.randint(0, w - self.output_size[1])
        h1 = np.random.randint(0, h - self.output_size[0])
        d1 = np.random.randint(0, d - self.output_size[2])
        if 'seg_label' in sample:
            label = sample['seg_label']
            # label = label[w1:w1 + self.output_size[0], h1:h1 + self.output_size[1], d1:d1 + self.output_size[2]]
            # label = label[:,d1:d1 + self.output_size[0],h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            label = label[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            # image = image[:,d1:d1 + self.output_size[0],h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            image = image[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            sample['image'] = image 
            sample['seg_label'] = label
        else:
            # image = image[:,d1:d1 + self.output_size[0], h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            image = image[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            sample['image'] = image
        return sample


class CenterCrop3d(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image = sample['image']
        # label = sample['seg_label']

        (c, h, w, d) = image.shape

        w1 = int(round((w - self.output_size[1]) / 2.))
        h1 = int(round((h - self.output_size[0]) / 2.))
        d1 = int(round((d - self.output_size[2]) / 2.))

        if 'seg_label' in sample:
            label = sample['seg_label']
            # label = label[w1:w1 + self.output_size[0], h1:h1 + self.output_size[1], d1:d1 + self.output_size[2]]
            # label = label[:,d1:d1 + self.output_size[0], h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            label = label[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            # image = image[:,d1:d1 + self.output_size[0], h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            image = image[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            sample['image'] = image 
            sample['seg_label'] = label
        else:
            # image = image[:,d1:d1 + self.output_size[0], h1:h1 + self.output_size[1], w1:w1 + self.output_size[2]]
            image = image[:,h1:h1 + self.output_size[0],w1:w1 + self.output_size[1],d1:d1 + self.output_size[2]]
            sample['image'] = image
        return sample


class RandomRotFlip3d(object):
    """
    Crop randomly flip the dataset in a sample
    Args:
    output_size (int): Desired output size
    """

    def __call__(self, sample):
        image = sample['image']

        # label = sample['seg_label']
        k = np.random.randint(0, 4)
        axis = np.random.randint(1, 4)
        if 'seg_label' in sample:
            label = sample['seg_label']
            image = np.stack([np.rot90(x,k) for x in image],axis=0)
            # label = np.rot90(label, k)
            label = np.stack([np.rot90(x, k) for x in label], axis=0)

            # axis = np.random.randint(1, 4)
            image = np.flip(image, axis=axis).copy()
            # label = np.flip(label, axis=axis-1).copy()
            label = np.flip(label, axis=axis).copy()

            sample['image'] = image 
            sample['seg_label'] = label
        else:
            image = np.stack([np.rot90(x,k) for x in image],axis=0)
            image = np.flip(image, axis=axis).copy()
            sample['image'] = image

        return sample


def augment_gaussian_noise(data_sample, noise_variance=(0, 0.1)):
    if noise_variance[0] == noise_variance[1]:
        variance = noise_variance[0]
    else:
        variance = random.uniform(noise_variance[0], noise_variance[1])
    data_sample = data_sample + np.random.normal(0.0, variance, size=data_sample.shape)
    return data_sample


class GaussianNoise3d(object):
    def __init__(self, noise_variance=(0, 0.1), p=0.5):
        self.prob = p
        self.noise_variance = noise_variance

    def __call__(self, sample):
        image = sample['image']
        # label = sample['seg_label']
        if np.random.uniform() < self.prob:
            image = augment_gaussian_noise(image, self.noise_variance)
            sample['image'] = image
        return sample


class ToTensor3d(object):
    """Convert ndarrays in sample to Tensors."""
    def __call__(self, sample):
        # image = sample['image']
        # label = sample['seg_label']
        if 'seg_label' in sample:
            image = sample['image']
            label = sample['seg_label']
            new_image = torch.from_numpy(image).float()
            label = torch.from_numpy(label).long()
            # return {'image': new_image, 'seg_label': label}
            sample['image'] = image
            sample['seg_label'] = label
            return sample
        else:
            image = sample['image']
            new_image = torch.from_numpy(image).float()
            return {'image': new_image}
        # return sample

class Compose3d(object):
    def __init__(self, transforms):
        self.transforms = transforms
    
    def __call__(self, sample):
        for t in self.transforms:
            sample = t(sample)
        return sample