import pandas as pd 
import os
from sklearn.model_selection import train_test_split
from sklearn.model_selection import StratifiedShuffleSplit, KFold, StratifiedKFold

def get_file_name(file_path, outfile_path, label:int):
    # 拿到数据的前缀名字，放到csv里面，方便训练处理
    file_list = os.listdir(file_path)
    # old_file_names = []
    new_file_names = []
    labels = []
    for file in file_list:
        # old_file_names.append(file)
        # new_file = file.strip().replace(' ', '-').replace('', '-')
        # file_texts = new_file.split('.')
        # if file_texts[0] == '' or file_texts[0] == ' ':
            # print(new_file)
            # print(file_texts)
        new_file_names.append(file)
        labels.append(label)
    csv_data = pd.DataFrame()
    csv_data['image_name'] = new_file_names
    csv_data['label'] = labels
    print('data size is {}'.format(len(labels)))
    csv_data.to_csv(outfile_path, index=False, sep='\t')

def merge_all_data_file(file_list, output_file):
    # 把每个类别的文件名合并到一起
    all_data = pd.DataFrame()
    for file_ in file_list:
        tmp_data = pd.read_csv(file_, sep='\t')
        all_data = pd.concat([all_data, tmp_data])
    
    all_data.to_csv(output_file, sep='\t', index=False)

def split_train_and_val(data_file):
    # 划分训练集和验证集
    all_data = pd.read_excel(data_file, converters={"Id": str})
    # all_data['seg_label'] = 1
    skf = StratifiedKFold(n_splits=5, random_state=42, shuffle=True)
    # kf = KFold(n_splits=5, shuffle=True)
    new_data = all_data.copy()
    new_data['fold'] = -1
    # train_index, val_index = train_test_split(all_data)
    for i, (train_index, val_index) in enumerate(skf.split(all_data['Id'], all_data['Classification_v3'])):
        print('train data size is {}'.format(len(train_index)))
        print('val data size is {}'.format(len(val_index)))
        new_data.loc[val_index, 'fold'] = i
    # new_data.drop(columns='seg_label', axis=1, inplace=True)
    new_data.to_excel(data_file[:-5]+'_class_v3_5fold_final.xlsx', index=False, float_format='%.0f')
if __name__ == '__main__':
    # get_file_name('../data/test_data/验证_对应患者1组/', '../data/test_data/patient_1.tsv', 1)
    # get_file_name('../data/test_data/验证_对应患者2组/', '../data/test_data/patient_2.tsv', 2)
    # get_file_name('../data/normal/', '../data/normal.tsv', 0)
    # merge_all_data_file(['../data/data_all_patient_sequence_and_label_name_fold.tsv', '../data/0629_corrected_patient_sequence_and_label_name_fold.tsv'], '../data/all_data_fold_new.tsv')
    split_train_and_val('../new_all_data_infos.xlsx')



