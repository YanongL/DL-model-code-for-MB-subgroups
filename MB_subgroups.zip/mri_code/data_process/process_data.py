from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import pandas as pd 
import cv2
import torch
import os
from skimage.transform import resize
# import torch
import albumentations as A 
from albumentations import (
    Compose, OneOf, Normalize, Resize, RandomResizedCrop, RandomCrop, HorizontalFlip, VerticalFlip, CenterCrop,
    RandomBrightness, RandomContrast, RandomBrightnessContrast, Rotate, ShiftScaleRotate, Cutout, HueSaturationValue,
    IAAAdditiveGaussianNoise, CoarseDropout, Transpose
    )
from albumentations.pytorch import ToTensorV2
import nibabel as nib
import numpy as np 
from .data_aug3d import CenterCrop3d, RandomCrop3d, ToTensor3d, GaussianNoise3d, RandomRotFlip3d, Compose3d

# A.Compose([
#     A.Transpose(p=0.5),
#     A.VerticalFlip(p=0.5),
#     A.HorizontalFlip(p=0.5),
#     A.RandomBrightness(limit=0.2, p=0.75),
#     A.RandomContrast(limit=0.2, p=0.75),
#     A.OneOf([
#         A.MotionBlur(blur_limit=5),
#         A.MedianBlur(blur_limit=5),
#         A.GaussianBlur(blur_limit=5),
#         A.GaussNoise(var_limit=(5.0, 30.0)),
#     ], p=0.7),

#     A.OneOf([
#         A.OpticalDistortion(distort_limit=1.0),
#         A.GridDistortion(num_steps=5, distort_limit=1.),
#         A.ElasticTransform(alpha=3),
#     ], p=0.7),

#     A.CLAHE(clip_limit=4.0, p=0.7),
#     A.HueSaturationValue(hue_shift_limit=10, sat_shift_limit=20, val_shift_limit=10, p=0.5),
#     A.ShiftScaleRotate(shift_limit=0.1, scale_limit=0.1, rotate_limit=15, border_mode=0, p=0.85),
#     A.Resize(image_size, image_size),
#     A.Cutout(max_h_size=int(image_size * 0.375), max_w_size=int(image_size * 0.375), num_holes=1, p=0.7),    
#     A.Normalize()
# ])
# csv_columns = ['StudyInstanceUID', 'PatientID']

# label_list = [0, 1, 2]

def get_transforms3d(phase):
    if phase == 'train':
        return Compose3d([
            # RandomRotFlip3d(),
            # GaussianNoise3d(p=0.1),
            ToTensor3d()
        ])
    else:
        return Compose3d([
            ToTensor3d()
        ])

class MriDataset(Dataset):
    def __init__(self, data_dir, df: pd.DataFrame, transforms2d=None, transforms3d=None, phase: str="train", is_resize: bool=True):
        self.data_dir = data_dir
        self.df = df
        self.phase = phase
        self.augmentations = transforms3d
        self.is_resize = is_resize
        self.augmentations_2d = transforms2d
        # self.max_slice = 0
        
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, idx):
        id_ = str(self.df.loc[idx, 'Id'])
        sequences_data = [str(self.df.loc[idx, 'sequence'])]
        # sequence_and_mask_names = os.listdir(os.path.join(self.data_dir, id_))
        # sequences_data = [x for x in sequence_and_mask_names if x != 'seg.nii.gz' and x != 'pred.nii.gz' and x != '.DS_Store']
        # if len(sequences_data) != 3:
        #     print(id_)
        # sequences_data = self.df.loc[idx, ['sequence_0', 'sequence_1', 'sequence_2']].values
        
        # root_path = self.df.loc[self.df['Brats20ID'] == id_]['path'].values[0]
        # load all modalities
        images = []
        cls_images = []
        for data_ in sequences_data:
            img_path = os.path.join(self.data_dir, id_, data_)
            # print(img_path)
            ori_img = self.load_img(img_path) # h x w x d
            # 首先判断一下看看有没有数据错误
            if ori_img.shape[0] != ori_img.shape[1]:
                ori_img = np.transpose(ori_img, (0, 2, 1))
            # 这里增加一个预处理
            img = self.irm_min_max_preprocess(ori_img)
            # 先手动把每个图片都补齐到固定的slice
            if img.shape[2] < 24:
                zero_image = np.zeros((img.shape[0], img.shape[1], 24-img.shape[2]))
                img = np.concatenate((img, zero_image), axis=-1)
            # 使用新的sample方法试一下，就是设定一个sample的比例，然后等间隔采样
            # img = self.sampling_slices(img, ax=2, keep_rate=0.1)
            # 这里首先使用每个sequence的middle的slice作为cls的img
            
            # img = img[:, :, 11]
            
            # img = ori_img[:, :, 2:18]
            if img.shape[0]!= 256 or img.shape[1]!=256:
                print('patient {} data has some error!, the slice num is {}'.format(id_, img.shape[2]))
            # img = np.transpose(img, (2, 0, 1)) # d x h x w
            norm_img = self.normalize(img)
            if self.is_resize:
                norm_img = self.resize(norm_img)
            
            # images.append(img[:, :, 2:18])
            images.append(norm_img)
            # cls_images.append(np.mean(norm_img, axis=-1))
            cls_images.append(norm_img)
        # 这里增加一个判断，给每个病人都拼上一个额外的sequence，确保每个都是4个sequence
        # if len(images) == 3:
        #     extra_image = np.zeros((256, 256, 24))
        #     images.append(extra_image)
        img = np.stack(images) / 255
        # cls_img = np.array(cls_images).transpose((1,2,0))
        # cls_img = cls_images[0] / 255
        # cls_img = np.stack(cls_images, axis=2) / 255
        cls_img = np.concatenate(cls_images, axis=2) / 255
        cls_img = cls_img.astype(np.float32)
        # seg_name = 'pred.nii.gz'
        # mask_path =  os.path.join(self.data_dir, id_,  seg_name)
        # mask = self.load_img(mask_path)
        # print(mask.shape)
        # cls_used_mask = mask[:, :, np.mean(mask, axis=(0, 1))>0]
        # cls_used_mask = np.mean(mask[:, :, 2:18], axis=-1, keepdims=True)
        # cls_used_mask = (cls_used_mask * 255).astype(np.uint8)
        # cls_used_mask = cls_used_mask / 255
        # print(cls_used_mask.shape)
        # cls_img = np.concatenate((cls_img, cls_used_mask), axis=-1)
        # cls_augment_res = self.augmentations_2d(image=cls_img)
        # cls_img = cls_augment_res['image']
        # get the classification info
        # cls_label = self.df.loc[idx, 'Classification']
        # print(img.shape)
        # img = np.transpose(img, (0, 3, 1, 2)) # (c x h x w x d) ---> (c x d x h x w)
        # print(img.shape)
        # 这里进行transform
        if self.augmentations:
            augmented = self.augmentations({"image": img})
            img = augmented['image']
        if self.augmentations_2d:
            cls_augment_res = self.augmentations_2d(image=cls_img)
            cls_img = cls_augment_res['image']

        if self.phase != "test":
            # seg_name = self.df.loc[idx, 'seg_label']
            seg_name = 'pred.nii.gz'
            mask_path =  os.path.join(self.data_dir, id_,  seg_name)
            mask = self.load_img(mask_path) # h x w x d
            # 直接取部分slice
            mask = mask[:, :, 2:18]
            
            # mask = np.transpose(mask, (2, 0, 1)) # d x h x w
            
            if self.is_resize:
                mask = self.resize(mask) # h x w x d
                # mask = mask[:, :, 2:18]
                mask = np.expand_dims(mask, axis=0)
                
                # 这里记得要根据分割的label的数量进行更改
                mask = np.clip(mask.astype(np.uint8), 0, 2).astype(np.float32)
                mask = np.clip(mask, 0, 2)
            # mask = self.preprocess_mask_labels(mask)
            # 在mask进行aug之前和cls_image拼接一下，看看效果
            # if self.augmentations:
            #     augmented = self.augmentations({"seg_label": mask})
            #     # img = augmented['image']
            #     mask = augmented['seg_label']
            # 搞一个cls_image，在slice维度上进行np.mean的操作
            # print(type(img))
            # cls_img = img[0]
            # cls_img = img[1]
            # cls_img = np.expand_dims(cls_img, axis=0)
            
            # # get the classification info
            cls_label = self.df.loc[idx, 'Classification_v3']
            # if cls_label == 5:
            #     cls_label = 0
            # else:
            #     cls_label = 1
            
            return {
                "Id": id_,
                "image": img,
                "mask": mask,
                "cls": cls_label-1,
                "cls_image": cls_img
            }
        else:
            # augmented = self.augmentations({"image": img})
            # img = augmented['image']
            # cls_augment_res = self.augmentations_2d(image=cls_img)
            # cls_img = cls_augment_res['image']
            return {
                "Id": id_,
                "image": img,
                "cls_image": cls_img
            }
    
    def load_img(self, file_path):
        data = nib.load(file_path)
        data = np.asarray(data.dataobj)
        # nib.load()读取的数据是旋转了90度，实际上的尺寸是w x h x d
        # rotate90度变成 h x w x d
        # data = np.rot90(data)
        # h x w x d
        return data
    
    def normalize(self, data: np.ndarray):
        data = data - np.min(data)
        data = data / np.max(data)
        image = (data * 255).astype(np.uint8)
        # data_min = np.min(data)
        # data = (data - data_min) / np.max(data)
        # image = (data * 255).astype(np.uint8)
        return image
        # return (data - data_min) / (np.max(data) - data_min)
    
    def resize(self, data: np.ndarray):
        # data = resize(data, (256, 256, 16), preserve_range=True)
        new_images = []
        for s in range(data.shape[2]):
            img_tmp = data[:, :, s]
            resized_img = cv2.resize(img_tmp, (256, 256))
            new_images.append(resized_img)
        new_data = np.stack(new_images, axis=2)
        return new_data
    
    def irm_min_max_preprocess(self, image, low_perc=1, high_perc=99):
        """Main pre-processing function used for the challenge (seems to work the best).

        Remove outliers voxels first, then min-max scale.

        Warnings
        --------
        This will not do it channel wise!!
        """

        non_zeros = image > 0
        low, high = np.percentile(image[non_zeros], [low_perc, high_perc])
        image = np.clip(image, low, high)
        # image = normalize(image)
        return image
    
    def sampling_slices(self, non_0_voxels, ax=2, keep_rate=0.1):
        '''Nearby slices are similar to each other, we use sample to only get the different ones'''
        total_slices = non_0_voxels.shape[ax]
        T = max(round(total_slices * keep_rate), 1)
        sampling_inds = np.arange(0, total_slices, T)
        
        if(ax==0):
            return non_0_voxels[sampling_inds]
        if(ax==1):
            return non_0_voxels[:, sampling_inds, :]
        if(ax==2):
            return non_0_voxels[:, :, sampling_inds]
# class Face_dataset(Dataset):

#     def __init__(self, df_data, data_path=None, transforms=None, mode='train'):
#         super(Face_dataset, self).__init__()
#         self.df_data = df_data
#         self.data_path = data_path
#         self.image_names = self.df_data['image_name'].values
#         self.labels = self.df_data['label'].values
#         self.mode = mode
#         self.transforms = transforms

#     def __len__(self):
#         return len(self.df_data)

#     def __getitem__(self, index):
#         img_name = self.image_names[index]
#         label = self.labels[index]
#         img_path = cv2.imread(os.path.join(self.data_path, img_name)) # 读取返回的是numpy.ndarray[H, W, C]
#         try:
#             img = cv2.cvtColor(img_path, cv2.COLOR_BGR2RGB) #[600,800,3]
        
    
#             label = torch.tensor(label, dtype=torch.long)
#             if self.transforms:
#                 argumented = self.transforms(image=img)
#                 img = argumented['image']
#             if self.mode == 'train' or self.mode == 'val':
#                 return img, label
#             elif self.mode == 'test':
#                 return img
#         except:
#             print('img path is {}'.format(img_name))

def get_transforms2d(phase):
    if phase == 'train':
        return Compose([
            Resize(512, 512),
            # RandomResizedCrop(512, 512),
            # RandomResizedCrop(256,256, scale=(0.85, 1.0)),
            # Transpose(p=0.5),
            # HorizontalFlip(p=0.5),
            # VerticalFlip(p=0.5),
            # RandomContrast(limit=0.2, p=0.2),
            # ShiftScaleRotate(shift_limit=0.025, scale_limit=0.1, rotate_limit=10, p=0.5),
            # HueSaturationValue(hue_shift_limit=0.2, sat_shift_limit=0.2, val_shift_limit=0.2, p=0.5),
            # RandomBrightnessContrast(brightness_limit=(-0.1,0.1), contrast_limit=(-0.1, 0.1), p=0.5),
            # CoarseDropout(p=0.1),
            # Cutout(p=0.1),
            # Normalize(
            #     mean=[0.485, 0.456, 0.406],
            #     std=[0.229, 0.224, 0.225],
            # ),
            ToTensorV2(),
        ])

    elif phase == 'val' or phase == 'test':
        return Compose([
            Resize(512, 512),
            # CenterCrop(380,380, p=1.),
            # Normalize(
            #     mean=[0.485, 0.456, 0.406],
            #     std=[0.229, 0.224, 0.225], 
            # ),
            ToTensorV2(),
        ])





if __name__ == '__main__':
    df_data = pd.read_excel('../all_data_infos_5fold.xlsx', converters={"Id": str})
    # new_df_data = df_data[df_data['image_name'] != None]
    # annotation_data = pd.read_csv('../data/train_annotations.csv')
    # train_transf = get_transforms('train')
    # augs = get_transforms3d('test')
    test_dataset = MriDataset('../data/', df_data, phase='train')
    train_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)
    for i, batch in enumerate(train_loader):
        # print(batch['Id'])
        # print(batch['mask'].size())
        # if len(np.unique(batch['mask'].numpy()).tolist()) != 3:
        #     print(batch['Id'])
        # print(np.unique(batch['mask'].numpy()))
        print(batch['image'].size())
        print(batch['cls_image'].size())
        break
        # mask = batch['mask'].squeeze(0).numpy()
        # x, y, z = np.nonzero(np.sum(img, axis=0) != 0)
        # # print(len(z))
        # # print(len(y))
        # # print(len(x))
        # ymin, xmin, zmin = [max(0, int(np.min(arr) - 1)) for arr in (y, x, z)]
        # ymax, xmax, zmax = [int(np.max(arr) + 1) for arr in (y, x, z)]
        # # print(ymin, xmin, zmin)
        # # print(ymax, xmax, zmax)
        # patient_image = img[:, ymin:ymax, xmin:xmax, zmin:zmax]
        # patient_label = mask[:, ymin:ymax, xmin:xmax, zmin:zmax]
        # # print(z)
        # # print(y)
        # # print(x)
        # print(patient_image.shape)
        # print(patient_label.shape)
        # break
    # print(type(train_dataset[0][0]))
    # print(train_dataset[0][0].shape)
    # from sklearn.model_selection import StratifiedKFold, KFold
    # skf = StratifiedKFold(n_splits=5, random_state=442)
    # for i, (train_index, val_index) in enumerate(skf.split(df_data['image_id'], df_data['label'])):
    #     print(len(train_index))
    #     print(len(val_index))
    