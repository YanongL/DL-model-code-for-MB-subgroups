import os
import nibabel as nib
from collections import defaultdict
import numpy as np 
import cv2

def my_resize(data: np.ndarray):
    new_images = []
    for s in range(data.shape[2]):
        img_tmp = data[:, :, s]
        resized_img = cv2.resize(img_tmp, (256, 256))
        new_images.append(resized_img)
    new_data = np.stack(new_images, axis=2)
    return new_data

def convert_img_size(input_dir, output_dir):
    patients = os.listdir(input_dir)
    patients = [x for x in patients if x!= '.DS_Store']
    for patient in patients:
        if patient.startswith('.'):
            os.remove(os.path.join(input_dir, patient))
            continue
        out_dir = os.path.join(output_dir, patient)
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        img_names = os.listdir(os.path.join(input_dir, patient))
        
        img_names = [x for x in img_names if x!='.DS_Store' and x!='pred.nii.gz']
        ori_data_slice = 0
        # img_affine = 0
        for img_name in img_names:
            if img_name.startswith('.'):
                os.remove(os.path.join(input_dir, patient, img_name))
                print('patient {} img name has error!!'.format(patient))
                continue
            
            nii_data = nib.load(os.path.join(input_dir, patient, img_name))
            data_slice = nii_data.get_fdata().shape[2]
            
            select_data = nii_data.get_fdata()[:, :, :24]
            # print(select_data.shape)
            ori_data_slice = select_data.shape[2]
            new_data = my_resize(select_data)
            out_path = os.path.join(out_dir, img_name)
            img_affine = nii_data.affine
            nib.save(nib.Nifti1Image(new_data.astype(np.float32), img_affine), out_path)
        # convert pred
        # pred_nii_data = nib.load(os.path.join(input_dir, patient, 'pred.nii.gz'))
        
        # data_slice = pred_nii_data.get_fdata().shape[2]
        
        # need_slice_num = ori_data_slice - data_slice
        # if need_slice_num < 0:
        #     print('patients {} data has some error'.format(patient))
        #     continue

    
        # empty_pred = np.zeros((pred_nii_data.get_fdata().shape[0], pred_nii_data.get_fdata().shape[1], need_slice_num))
        
        # print(patient)
        # new_preds = np.concatenate((pred_nii_data.get_fdata(), empty_pred), axis=2)
        # assert new_preds.shape[2] == ori_data_slice
        # out_path = os.path.join(out_dir, 'pred.nii.gz')
        # img_affine = pred_nii_data.affine
        # nib.save(nib.Nifti1Image(new_preds.astype(np.float32), img_affine), out_path)
        # need_slice_num = data_slice - preds.size(2)
        # empty_pred = torch.zeros((preds.size(0), preds.size(1), need_slice_num))
        # new_preds = torch.cat((preds, empty_pred), dim=-1)
        # assert new_preds.size(2) == data_slice
        

        # out_path = os.path.join(out_dir, img_name)
        # img_affine = nii_data.affine
        # nib.save(nib.Nifti1Image(new_data.astype(np.float32), img_affine), out_path)
        print('resize patient {} succeed!'.format(patient))

if __name__ == '__main__':
    convert_img_size('../data/', '../data_resized/')