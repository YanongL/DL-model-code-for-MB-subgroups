import torch
import torch.nn as nn 
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler 
from tqdm import tqdm
import numpy as np 
import os
import pandas as pd 
from torch.optim.lr_scheduler import ReduceLROnPlateau, CosineAnnealingWarmRestarts, CosineAnnealingLR
from data_process.process_data import MriDataset
from models.model import ResNext, SeResNext, EfficientNet, Xception, ResNet
from models.unet3d import UNet3d
from models.segresnet3d import SegResNet
from models.vnet3d import VNet
from models.resunet import ResUNet3d
from models.unetr import UNETR
from models.attention_unet3d import AttentionUnet
from models.unet3dpp import UNetPlusPlus
from monai.losses import DiceLoss, DiceCELoss, DiceFocalLoss
# from segmentation_models_pytorch.losses import DiceLoss
from utils.util import seed_everything, get_logger, get_argparse, get_result, get_score


# torch.cuda.set_device(1)
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def train_epoch(model, train_dataloader, optimizer, loss_fn, scaler):
    # one epoch train
    model.train()
    train_pbar = tqdm(enumerate(train_dataloader), total=len(train_dataloader))
    train_losses = 0.0
    # all_labels = []
    # all_preds = []
    for step, batch_data in train_pbar:
        optimizer.zero_grad()
        img = batch_data['image'].to(device, non_blocking=True, dtype=torch.float)
        label = batch_data['mask'].to(device, non_blocking=True, dtype=torch.float)
        # print(label)
        # print(label.size())
        # torch.amp
        with autocast():
            out = model(img)
            loss = loss_fn(out, label)
        train_losses += loss.item()

        scaler.scale(loss).backward()
        # 梯度裁剪前需要调用下面这个
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1000)
        # all_preds.extend([out.sigmoid().detach().to('cpu').numpy()]) # 对记录的模型输出进行sigmoid处理
        # all_labels.extend([label.detach().cpu('cpu').numpy()])
        # optimizer.zero_grad()
        # loss.backward()
        # pytorch 自带加速
        # scaler.scale(loss).backward()
        scaler.step(optimizer)
        scaler.update()
        # apex加速训练
        # with amp.scale_loss(loss, optimizer) as scaled_loss:
        #     scaled_loss.backward()
        # optimizer.step()
    # all_labels = np.concatenate(all_labels)
    # all_preds = np.concatenate(all_preds)
    # train_acc = np.mean(all_labels==all_preds)
    # train_score = get_score(all_labels, all_preds)

    # 清空GPU缓存
    torch.cuda.empty_cache()
    
    return train_losses / len(train_dataloader)
        

def val_epoch(model, val_dataloader, loss_fn):
    # one epoch val
    model.eval()
    val_pbar = tqdm(enumerate(val_dataloader), total=len(val_dataloader))
    val_losses = 0.0
    all_preds = []
    all_labels = []
    all_pred_logits = []
    with torch.no_grad():
        for step, batch_data in val_pbar:
            img = batch_data['image'].to(device, non_blocking=True, dtype=torch.float)
            label = batch_data['mask'].to(device, non_blocking=True, dtype=torch.float)
            out = model(img)
            loss = loss_fn(out, label)
            val_losses += loss.item()
            # 保存预测的标签和样本label
            # preds = torch.sigmoid(out)
            # 这里使用monai的dicescore计算的时候使用的是tensor, 并且是原始的logits不是softmax之后的
            # preds = torch.softmax(out, dim=1)
            # pred_logits, preds = torch.max(preds, dim=-1)
            # preds = torch.argmax(preds, dim=1)
            # print(preds.size())
            # 这里也要注意，目前使用的monai的函数，是不需要转softmax的
            all_preds.extend([out.to('cpu')]) # 对记录的模型输出进行softmax处理
            all_labels.extend([label.to('cpu')])
                              
            # all_preds.extend([out.to('cpu').numpy()]) # 对记录的模型输出进行softmax处理
            # all_labels.extend([label.to('cpu').numpy()])
            # all_pred_logits.extend([pred_logits.to('cpu').numpy()])
        
        all_preds = torch.concat(all_preds)
        all_labels = torch.concat(all_labels)
        # all_pred_logits = np.concatenate(all_pred_logits)
        # print(all_labels.shape)
        # val_acc = np.mean(all_preds==all_labels)
        val_score = get_score(all_preds, all_labels)
        # print(val_score)

    return val_losses / len(val_dataloader), val_score, all_preds

def train_loop(model, train_loader, val_loader, val_df, loss_fn, optimizer, scheduler, args):
    # main train function
    # logger.info('------------Fold {} Training is start!-------------'.format(fold))
    best_val_score = 0.0
    # best_val_loss = np.inf
    early_stop_cnt = 0
    scaler = GradScaler()
    for epoch in range(args.epochs):
        train_epoch_loss = train_epoch(model, train_loader, optimizer, loss_fn, scaler)
        val_epoch_loss, val_epoch_score, val_epoch_preds = val_epoch(model, val_loader, loss_fn)

        logger.info('Epoch {}: Train loss is {:.4f}, Val loss is {:.4f}' \
                                        .format(epoch+1, train_epoch_loss, val_epoch_loss))

        logger.info('Epoch {}: Val score is {:.4f}'.format(epoch+1, val_epoch_score))

        scheduler.step()
        # scheduler.step(val_epoch_loss)
        # scheduler_warmup.step()

        # if val_epoch_score > best_val_score:
        #     best_val_score = val_epoch_score
        #     logger.info('Best score is {:.4f}'.format(best_val_score))
        #     logger.info('Update model in epoch {}'.format(epoch+1))
        #     output_dir = os.path.join(args.saved_dir, args.model_name)
        #     if not os.path.exists(output_dir):
        #         os.makedirs(output_dir)
        #     saved_model_path = os.path.join(output_dir, 'fold_{}_best.pth'.format(fold))
        #     checkpoint = {
        #         'epoch': epoch + 1,
        #         'state_dict': model.state_dict(),
        #         'optim_state_dict': optimizer.state_dict(),
        #         'preds':val_epoch_preds,
        #         # 'amp': amp.state_dict()                    
        #     }
        #     torch.save(checkpoint, saved_model_path)


        if val_epoch_score > best_val_score:
            early_stop_cnt = 0
            # best_val_score = val_epoch_score
        # if val_epoch_score < best_val_loss:
            # best_val_loss = val_epoch_loss
            logger.info('Best Score is from {:.4f} to {:.4f}'.format(best_val_score, val_epoch_score))
            best_val_score = val_epoch_score
            logger.info('Update model in epoch {}'.format(epoch+1))
            output_dir = os.path.join(args.saved_dir, args.model_name)
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
            saved_model_path = os.path.join(output_dir, 'best.bin')
            checkpoint = {
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                # 'optim_state_dict': optimizer.state_dict(),
                # 'preds':val_epoch_preds,
                # 'pred_logits': val_pred_logits
                # 'amp': amp.state_dict()                    
            }
            torch.save(checkpoint, saved_model_path)
        else:
            early_stop_cnt += 1
        # 清空GPU缓存
        torch.cuda.empty_cache()
        # 进行early stop的操作
        if early_stop_cnt > 10:
            logger.info('The evaluate metric had {} times not has update, so need to early stop!!!'.format(early_stop_cnt))
            break
    # 存储每个fold集中的最好的模型在val上的结果
    # output_dir = os.path.join(args.saved_dir, args.model_name)
    # check_point = torch.load(os.path.join(output_dir, 'best.bin'))
    # val_df['pred'] = check_point['preds']
    # val_df['pred'] = val_df['pred'].round(4)
    # val_df['pred_logits'] = check_point['pred_logits']
    # val_df['pred_logits'] = val_df['pred_logits'].round(4)

    # logger.info('The best loss is {:.4f}'.format(best_val_loss))
    logger.info('The best score is {:.4f}'.format(best_val_score))
    # logger.info('------------Fold {} Training is end!-------------'.format(fold))

    return val_df



def main(args):
    # main function
    seed_everything()
    df_data = pd.read_excel('all_data_infos.xlsx', converters={"Id": str})
    # gkf = GroupKFold(n_splits=5)
    # train_transforms = get_transforms(mode='train')
    # val_transforms = get_transforms(mode='val')
    # image_path = os.path.join(args.data_dir, 'dataset')
    oof_df = pd.DataFrame() # 用于存储每个fold的,每个最佳模型的val结果
    # groups = df_data['PatientID'].values
    # for fold, (train_index, val_index) in enumerate(gkf.split(df_data, df_data[label_list], groups)):
        
    # 加载数据
    train_df_data = df_data[df_data['is_train'] == 1]
    train_df_data = train_df_data.reset_index(drop=True)
    # print(train_df_data.head())
    print('Training data size is {}'.format(len(train_df_data)))
    val_df_data = df_data[df_data['is_train'] == 0]
    val_df_data = val_df_data.reset_index(drop=True)
    print('Val data size is {}'.format(len(val_df_data)))
    val_df = val_df_data.reset_index(drop=True) # 生成val_df用于存储val的结果
    # print(val_df.head())
    train_dataset = MriDataset('./data/data_all_new', train_df_data, phase='train', is_resize=True)
    val_dataset = MriDataset('./data/data_all_new', val_df_data, phase='val', is_resize=True)
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True, num_workers=4, pin_memory=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=2, shuffle=False, num_workers=4, pin_memory=True, drop_last=False)

    # 设置模型及优化器
    logger.info('The model is using {}'.format(args.model_name))
    # model = EfficientNet(model_name=args.model_name, pretrained=True, n_class=len(label_list))
    # model = SeResNext(model_name=args.model_name, pretrained=True, n_class=len(label_list))
    # model = ResNext(model_name=args.model_name, pretrained=True, n_class=len(label_list))
    # model = Xception(model_name=args.model_name, pretrained=True, n_class=len(label_list))
    # model = UNet3d(spatial_dims=3, in_channels=3, out_channels=3, dropout=0.1)
    # model = UNet3d(spatial_dims=3, in_channels=3, out_channels=3, features=(64, 64, 128, 256, 512, 64), dropout=0.1)
    # model = ResUNet3d(in_channels=3, n_classes=3, n_channels=16)
    # model = VNet(spatial_dims=3, in_channels=3, out_channels=3, dropout_prob=0.1)
    # model = SegResNet(spatial_dims=3, in_channels=3, out_channels=3, dropout_prob=0.1)
    model = UNetPlusPlus(in_channels=3, out_channels=3, features=(64, 128, 256, 512, 1024, 128), dropout=0.1)
    # model = ResNet(model_name=args.model_name, pretrained=True, n_class=len(label_list))
    # model = VNet_v2(in_channels=3, classes=3)
    # model = UNETR(in_channels=3, out_channels=3, img_size=(256, 256, 16), dropout_rate=0.1)
    # model = AttentionUnet()
    model.to(device)

    # 多卡并行训练
    # if torch.cuda.device_count() > 1:
    #     logger.info("Let's use", torch.cuda.device_count(), "GPUs!")
    #     model = nn.DataParallel(model)
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    # optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    # optimizer = RAdam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    # optimizer = Lookahead(RAdam(model.parameters(),lr=0.00001), alpha=0.5, k=5)

    # scheduler进行lr调整
    # scheduler = ReduceLROnPlateau(optimizer, mode='min', patience=3)
    # scheduler = CosineAnnealingWarmRestarts(optimizer, 100, eta_min=1e-7, last_epoch=-1)
    scheduler = CosineAnnealingLR(optimizer, T_max=100, eta_min=1e-7, last_epoch=-1)

    # loss function
    # loss_fn = MultiClassDiceLoss(n_classes=3) # 现在计算是默认去除background的
    # loss_fn = DiceLoss(include_background=False, to_onehot_y=True, softmax=True)
    loss_fn = DiceCELoss(include_background=False, to_onehot_y=True, softmax=True, lambda_ce=0.1, lambda_dice=0.9)
    # loss_fn = DiceFocalLoss(include_background=False, to_onehot_y=True, softmax=True, lambda_focal=0.1, lambda_dice=0.9)

    # 使用apex加速训练
    # model, optimizer = amp.initialize(model, optimizer, opt_level='O1')

    # 记录参数以及优化器相关
    logger.info('The optimizer is {}'.format(optimizer))
    logger.info('The scheduler is {}'.format(scheduler))
    logger.info('The loss function is {}'.format(loss_fn))
    
    # 训练和保存结果
    _oof_df = train_loop(model, train_loader, val_loader, val_df, loss_fn, optimizer, scheduler, args)
    # oof_df = pd.concat([oof_df, _oof_df])
    # 保存oof result
    # oof_df.to_csv('./oof_df.tsv', index=False, sep='\t')
    # logger.info('----------------CV result-----------------')
    # logger.info('The Training Best Score is {:.4f}'.format(get_result(oof_df)))
    # logger.info('------------------------------------------')
    logger.info('All Training is End!')
    



if __name__ == '__main__':
    args = get_argparse()
    args.data_dir = './data/'
    args.saved_dir = './saved'
    args.model_name = 'unetpp'
    args.epochs = 100
    args.lr = 1e-4
    args.logs_dir = os.path.join('./logs', args.model_name)
    logger = get_logger(args.logs_dir)
    main(args)


