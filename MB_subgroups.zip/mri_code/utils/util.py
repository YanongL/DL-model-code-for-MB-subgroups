from logging import getLogger, INFO, FileHandler,  Formatter,  StreamHandler
import argparse
import random
import os
import torch
import numpy as np
from sklearn.metrics import roc_auc_score, classification_report, accuracy_score, f1_score
from monai.metrics import DiceHelper

def get_argparse():
    parser = argparse.ArgumentParser()
    ## Required parameters
    parser.add_argument("--data_dir", default=None, type=str, required=False,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--saved_dir", default=None, type=str, required=False,
                        help="The output directory where the model predictions and checkpoints will be written.")
    parser.add_argument("--logs_dir", default=None, type=str, required=False,
                        help="The logs directory.")
    parser.add_argument("--model_name", default=None, type=str, required=False,
                        help="What model to use in training!")
    parser.add_argument("--image_size", default=256, type=int, required=False,
                        help="The image size using!")

    parser.add_argument("--weight_decay", default=1e-6, type=float,
                        help="Weight decay if we apply some.")
    parser.add_argument("--warmup_proportion", default=0.1, type=float,
                        help="Proportion of training to perform linear learning rate warmup for,E.g., 0.1 = 10% of training.")
    parser.add_argument("--lr", default=1e-4, type=float,
                        help="The initial learning rate for Adam.")
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--epochs", default=10, type=int,
                        help="Total number of training epochs to perform.")
    parser.add_argument("--warmup_steps", default=3, type=int,
                        help="Linear warmup over warmup_steps.")
    parser.add_argument("--seed", type=int, default=42,
                        help="random seed for initialization")

    parser.add_argument("--fp16", default=False, action="store_true",
                        help="Whether to use 16-bit (mixed) precision (through NVIDIA apex) instead of 32-bit")
    

    args = parser.parse_args()
    return args

def get_logger(logs_dir):
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir)
    log_file_path = os.path.join(logs_dir, 'train.log')
    logger = getLogger(__name__)
    logger.setLevel(INFO)
    handler1 = StreamHandler()
    handler1.setFormatter(Formatter("%(message)s"))
    handler2 = FileHandler(filename=log_file_path)
    handler2.setFormatter(Formatter("%(message)s"))
    logger.addHandler(handler1)
    logger.addHandler(handler2)
    return logger

def seed_everything(seed=42):
    '''
    设置整个开发环境的seed
    :param seed:
    :param device:
    :return:
    '''
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # some cudnn methods can be random even after fixing the seed
    # unless you tell it to be deterministic
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def get_score(preds, labels):
    # 新的metrics计算方式
    # return np.mean([roc_auc_score(labels[:, i], preds[:, i]) for i in range(11)])
    dice_func = DiceHelper(include_background=False, softmax=True, reduction='mean', num_classes=3, get_not_nans=False)
    dice_score = dice_func(preds, labels) # 返回的是tensor
    return dice_score.item()


def get_result(result_df):
    #计算local CV
    preds = result_df['pred'].values.tolist()
    labels = result_df['label'].values.tolist()
    score = get_score(torch.tensor(preds), torch.tensor(labels))
    return score

def get_cls_score(preds, labels):
    # 计算分类的指标，暂定用f1来表示
    f1 = f1_score(preds, labels, average='micro')
    return f1

def get_cls_result(result_df):
    preds = result_df['pred'].values.tolist()
    labels = result_df['label'].values.tolist()
    score = get_cls_score(preds, labels)
    return score


# def cal_dice(preds, labels):

def dice_coef_metric(probabilities: torch.Tensor,
                     truth: torch.Tensor,
                     treshold: float = 0.5,
                     eps: float = 1e-9) -> np.ndarray:
    """
    Calculate Dice score for data batch.
    Params:
        probobilities: model outputs after activation function.
        truth: truth values.
        threshold: threshold for probabilities.
        eps: additive to refine the estimate.
        Returns: dice score aka f1.
    """
    scores = []
    # probabilities = probabilities.squeeze(1)
    num = probabilities.shape[0]
    # predictions = (probabilities >= predictions).float()
    predictions = torch.softmax(probabilities, dim=1)
    predictions = torch.argmax(predictions, dim=1, keepdim=True)

    assert(predictions.shape == truth.shape)
    for i in range(num):
        prediction = predictions[i]
        truth_ = truth[i]
        intersection = 2.0 * (truth_ * prediction).sum()
        union = truth_.sum() + prediction.sum()
        if truth_.sum() == 0 and prediction.sum() == 0:
            scores.append(1.0)
        else:
            scores.append((intersection + eps) / union)
    return np.mean(scores)