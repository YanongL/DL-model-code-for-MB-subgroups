import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import numpy as np 
import os
import pandas as pd 
import random
from data_process.process_data import MriDataset
from models.model import ResNext, SeResNext, EfficientNet, ResNet
from models.unet3d import UNet3d
from models.segresnet3d import SegResNet
from models.vnet3d import VNet
from models.unet3dpp import UNetPlusPlus
from utils.util import get_score
import nibabel as nib

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

# def load_state(model_path):
#     model = ResNext(, pretrained=False)
#     try:  # single GPU model_file
#         model.load_state_dict(torch.load(model_path)['model'], strict=True)
#         state_dict = torch.load(model_path)['model']
#     except:  # multi GPU model_file
#         state_dict = torch.load(model_path)['model']
#         state_dict = {k[7:] if k.startswith('module.') else k: state_dict[k] for k in state_dict.keys()}

#     return state_dict
def predict_cls(model, states, test_loader, device):
    model.to(device)
    tk0 = tqdm(enumerate(test_loader), total=len(test_loader))
    probs = []
    for i, (images) in tk0:
        images = images.to(device)
        avg_preds = []
        for state in states:
            model.load_state_dict(state['state_dict'])
            model.eval()
            with torch.no_grad():
                y_preds = model(images)
            avg_preds.append(y_preds.softmax(1).detach().cpu().numpy())
        avg_preds = np.mean(avg_preds, axis=0)
        probs.append(avg_preds)
    probs = np.concatenate(probs)
    return probs

def predict(model, test_loader, device, test_data_dir):
    model.to(device)
    model.eval()
    tk0 = tqdm(enumerate(test_loader), total=len(test_loader))
    all_preds = []
    all_patients = []
    for i, batch_data in tk0:
        images = batch_data['image'].to(device)
        patients = batch_data['Id']
        # print(patients)
        sequence_names = os.listdir(os.path.join(test_data_dir, str(patients[0])))
        used_sequence = [x for x in sequence_names if x!='seg.nii.gz' and x!='pred.nii.gz' and x!='.DS_Store']
        # print(patients[0])
        # model.eval()
        # avg_preds = []
        # for state in states:
            # model.load_state_dict(state['state_dict'])
            # model.eval()
        with torch.no_grad():
            out = model(images)
            # preds = torch.sigmoid(out)
            preds = torch.softmax(out, dim=1)
            # avg_preds.append(out.softmax(1).detach().cpu().numpy())
            preds = torch.argmax(preds, dim=1)
            # print(preds.size())
            # pred_logits, preds = torch.max(preds, dim=-1)
        # avg_preds = np.mean(avg_preds, axis=0)
        all_preds.extend([preds.to('cpu').numpy()])
        all_patients.extend(patients)
        # 这里把预测的分割结果存到对应的病人的目录下面
        preds = preds.squeeze(0).to('cpu')
        preds_out_path = os.path.join(test_data_dir, patients[0], 'pred.nii.gz')
        ori_data = nib.load(os.path.join(test_data_dir, patients[0], used_sequence[0]))
        data_slice = ori_data.get_fdata().shape[2]
        need_slice_num = data_slice - preds.size(2)
        empty_pred = torch.zeros((preds.size(0), preds.size(1), need_slice_num))
        new_preds = torch.cat((preds, empty_pred), dim=-1)
        assert new_preds.size(2) == data_slice
        img_affine = ori_data.affine
        nib.save(nib.Nifti1Image(new_preds.numpy().astype(np.float32), img_affine), preds_out_path)
        # print('patient - {} pred result has been writed!'.format(patients[0]))
        # all_pred_logits.extend([pred_logits.to('cpu').numpy()])
    # avg_preds = np.mean(avg_preds, axis=0)
    # probs.append(avg_preds)
    # all_preds = np.concatenate(all_preds)
    assert len(all_patients) == len(all_preds)
    # all_pred_logits = np.concatenate(all_pred_logits)
    return all_patients


if __name__ == '__main__':
    model_name = 'unetpp'
    output_dir = './saved'
    test_data_path = './data_resized/'
    df_data = pd.read_excel('final_data_infos.xlsx', converters={"检查流水号": str})
    # test_df = df_data[df_data['is_train'] == 0].reset_index(drop=True)
    # model = UNet3d(spatial_dims=3, in_channels=3, out_channels=3, dropout=0.1)
    model = UNetPlusPlus(in_channels=3, out_channels=3, features=(128, 128, 256, 512, 1024, 128), dropout=0.1)

    # model = ResNet(model_name=model_name, pretrained=False, n_class=3)
    # states = [torch.load(output_dir+f'fold-{fold}_best.pth') for fold in range(5)]
    model.load_state_dict(torch.load(os.path.join(output_dir, model_name, 'fold-0_best.bin'))['state_dict'])
    test_dataset = MriDataset(test_data_path, df_data, phase='test', is_resize=True)
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, 
                                num_workers=4, pin_memory=True)
    preds = predict(model, test_loader, device, test_data_path)
    # 对preds进行阈值限定，大于0.5的为1
    # preds = (preds > 0.5)
    # nib.save(nib.Nifti1Image(preds.astype(np.float32), np.eye(4)), path)
    # print('Test data metric is {:.4f}'.format(get_score(test_df_data['label'].values, preds)))
    # submission
    # test_df_data['preds'] = preds
    # test_df_data['pred_logits'] = pred_logits
    # test_df_data[['image_name', 'label', 'preds', 'pred_logits']].to_csv('./test_data_pred.tsv', index=False, sep='\t')