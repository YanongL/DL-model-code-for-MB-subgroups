import monai
from monai.networks.nets import ResNet, resnet50
import torch
test_model = resnet50(pretrained=False, spatial_dims=3, n_input_channels=3, num_classes=5)
test_input = torch.rand((2, 3, 256, 256, 16))
test_out = test_model(test_input)
print(test_out.size())


# if __name__ == '__main__':
#     test_model = ResNet()